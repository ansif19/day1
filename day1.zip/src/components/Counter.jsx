import { Button, Typography } from '@mui/material'
import React, { useState } from 'react'

const Counter = () => {
    var [count,SetCount] = useState(0) 

    const IncBtn =()=> {
        console.log("inc clicked")
        SetCount(count+1)
    }
    const dicBtn =()=> {
        console.log("dec clicked")
        SetCount(count-1)
    }
  return (
    <div style={{paddingTop:"80px"}}>
        <Typography>Counter value:{count}</Typography>
        <Button variant='contained'color='success'onClick={IncBtn}>+</Button>
        <Button variant='contained'color='error'onClick={dicBtn}>-</Button>
    </div>
  )
}
export default Counter
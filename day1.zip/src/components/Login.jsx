import { TextField, Typography } from '@mui/material'
import React from 'react'

const Login = () => {
  return (
    <div>Login<br></br><br></br>
        
        <input type="password" placeholder='password' />
        <br></br>
        <Typography variant='h4'>HELLO</Typography>
        <TextField id="outlined-basic" label="username" variant="outlined" />        
        
    </div>
  )
}

export default Login
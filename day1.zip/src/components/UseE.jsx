import { Button, Typography } from '@mui/material'
import React, { useState } from 'react'

const UseE = () => {
    var[hname,setName]=useState()

    const chageHname =()=>{

        setName("Home")
    }
    const changeGname=()=>{

        setName("Contact")
    }
    const changeCname=()=>{
        setName("Gallary")

    }

  return (
    <div style={{paddingTop:"80px"}}>
        <Button variant='contained'color='primary'onClick={chageHname}>Home</Button>&nbsp;
        <Button variant='contained'color='secondary'onClick={changeGname}>Gallary</Button>&nbsp;
        <Button variant='contained'color='error'onClick={changeCname}>Contact</Button>&nbsp;
        <Typography>Welcome to{hname}</Typography>
    </div>
  )
}

export default UseE
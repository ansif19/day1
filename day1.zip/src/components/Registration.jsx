import { TextField, Typography } from '@mui/material'
import React from 'react'

const Registration = () => {
  return (
    <div>
        <Typography variant='h4'>Registration</Typography><br>
        </br>
      <TextField label="username "variant='outlined'></TextField><br></br>
      <br></br>
      <input type='date' ></input><br></br><br></br>
      <input type='password' placeholder='password'></input>
    </div>
  )
}

export default Registration
import { Button, Typography } from '@mui/material'
import React, { useState } from 'react'

const StateBasics = () => {
    // var fname='ansif'
    var [fname,SetFname]=useState('ansif')
    const changename =()=>{
        console.log("clicked")
        SetFname("hihihee")
    }
  return (
    <div style={{paddingTop:"80px"}}>
        <Typography variant='h4'>welcome  {fname}</Typography>
        <Button variant='contained' onClick={changename}>change</Button>
    </div>
  )
}

export default StateBasics